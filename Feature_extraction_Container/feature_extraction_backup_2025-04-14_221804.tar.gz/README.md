# fMRI Feature Extraction

This repository contains scripts for calculating various features from fMRI data.

## Features

Currently, the following feature extraction methods are implemented:

- **ReHo** (Regional Homogeneity): Calculates the similarity of the time series of a given voxel to those of its nearest neighbors using AFNI's 3dReHo
- **ALFF** (Amplitude of Low-Frequency Fluctuation): Measures the total power of a low-frequency range (typically 0.01-0.08 Hz)

## Usage

### Single Feature Extraction

Each feature can be run individually:

#### ReHo

```bash
python scripts/reho.py --fmri <input_fmri_file> --output <output_file> [--cluster-size <7|19|27>] [--mask <mask_file>]
```

#### ALFF

```bash
python scripts/alff.py --fmri <input_fmri_file> --output <output_file> [--tr <repetition_time>] [--low <freq>] [--high <freq>] [--mask <mask_file>]
```

### Running All Features

To extract all features with one command:

```bash
python scripts/run_features.py --input <input_fmri_file> --output-dir <output_directory> [--tr <repetition_time>] [--mask <mask_file>] [--reho-cluster-size <7|19|27>] [--alff-low <freq>] [--alff-high <freq>]
```

## Parameters

- **fmri/input**: Path to the input fMRI file (NIFTI format)
- **output/output-dir**: Path to output file or directory
- **tr**: Repetition time in seconds (default: 2.0)
- **mask**: Optional binary mask file (if not provided, one will be generated from the data)

### ReHo Parameters
- **cluster-size**: Size of the cluster for ReHo calculation (7, 19, or 27; default: 27)

### ALFF Parameters
- **low/bandpass-low**: Lower bound of bandpass filter in Hz (default: 0.01)
- **high/bandpass-high**: Upper bound of bandpass filter in Hz (default: 0.08)

## Dependencies

- Python 3.6+
- NumPy
- Nibabel
- SciPy
- AFNI (for ReHo calculation)

## License

This project is licensed under the MIT License - see the LICENSE file for details. 